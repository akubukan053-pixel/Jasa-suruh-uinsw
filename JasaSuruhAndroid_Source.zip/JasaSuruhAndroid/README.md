# Jasa Suruh UINSW Android

Project Android Studio yang membungkus aplikasi HTML Kalkulator HPP Pro ke dalam Android WebView.

## Cara membuat APK
1. Ekstrak ZIP project.
2. Buka folder `JasaSuruhAndroid` melalui Android Studio.
3. Tunggu Gradle Sync selesai (butuh koneksi internet untuk mengunduh Android Gradle Plugin).
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug akan muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Fitur
- Memuat aplikasi HTML secara lokal, tanpa server.
- Penyimpanan data browser lokal melalui DOM Storage.
- Pemilihan file untuk logo dan restore backup.
- Unduhan CSV/JSON melalui Download Manager Android.
- Cetak laporan melalui Android Print Framework.

## Catatan
Data order dan pengaturan disimpan lokal pada perangkat (localStorage), belum tersinkron ke cloud/database. Backup secara berkala melalui menu aplikasi.
